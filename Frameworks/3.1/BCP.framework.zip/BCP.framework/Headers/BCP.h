//
//  BCP.h
//  BCP
//
//  Created by Andrey Kozhurin on 20/03/2017.
//  Copyright © 2017 Andrey Kozhurin. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for BCP.
FOUNDATION_EXPORT double BCPVersionNumber;

//! Project version string for BCP.
FOUNDATION_EXPORT const unsigned char BCPVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BCP/PublicHeader.h>


